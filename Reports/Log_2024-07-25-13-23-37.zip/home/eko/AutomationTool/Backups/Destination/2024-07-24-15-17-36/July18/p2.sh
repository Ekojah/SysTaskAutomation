echo "Please enter your name ="
read name

echo "hello - $name, welcome to the hub"


