for i in {1..10}
do
	if (( i==5)); then
		break
	fi
	echo $i
done
