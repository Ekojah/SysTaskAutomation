for i in $(10 1)
do
	echo $i
done
