echo "If condition example"

read -p "enter a num" num

if []
