echo " Filename = $0 "

echo "Filename "

echo
