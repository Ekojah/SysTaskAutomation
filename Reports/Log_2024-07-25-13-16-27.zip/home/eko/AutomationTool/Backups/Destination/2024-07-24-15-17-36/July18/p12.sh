for i in $(seq 10 -1 2)
do
	echo $i
done
