for i in {1..8}
do
	echo $i
	sleep 5
done
