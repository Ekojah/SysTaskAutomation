echo "Filename = $0 "

echo "$#"

echo "$@"

for i in "$@"
do
	echo$i
done
