echo "Hi this is a wonderful day! Nice to see you all happy"
echo "this is a new line"
